#ifndef __SERVER_H__
#define __SERVER_H__


// reads from authentication.txt and stores at in server.c as a data structure
void readAccounts(void);


#endif //__SERVER_H__